const StockMovement = require("../models/StockMovement")
const Product = require("../models/Product")
const User = require("../models/User")

// Get all stock movements
const getAllStockMovements = async (req, res) => { 
  try {
    const stockMovements = await StockMovement.findAll({
      include: [
        {
          model: Product,
          attributes: ["name", "sku"],
        },
        {
          model: User,
          attributes: ["username"],
        },
      ],
      order: [["createdAt", "DESC"]],
    })

    res.status(200).json(stockMovements)
  } catch (error) {
    res.status(500).json({ message: "Error fetching stock movements", error: error.message })
  }
}

// Get stock movements for a specific product
const getProductStockMovements = async (req, res) => {
  try {
    const { productId } = req.params

    const stockMovements = await StockMovement.findAll({
      where: { productId },
      include: [
        {
          model: Product,
          attributes: ["name", "sku"],
        },
        {
          model: User,
          attributes: ["username"],
        },
      ],
      order: [["createdAt", "DESC"]],
    })

    res.status(200).json(stockMovements)
  } catch (error) {
    res.status(500).json({ message: "Error fetching product stock movements", error: error.message })
  }
}

// Get stock movement by ID
const getStockMovementById = async (req, res) => {
  try {
    const { id } = req.params

    const stockMovement = await StockMovement.findByPk(id, {
      include: [
        {
          model: Product,
          attributes: ["name", "sku"],
        },
        {
          model: User,
          attributes: ["username"],
        },
      ],
    })

    if (!stockMovement) {
      return res.status(404).json({ message: "Stock movement not found" })
    }

    res.status(200).json(stockMovement)
  } catch (error) {
    res.status(500).json({ message: "Error fetching stock movement", error: error.message })
  }
}

module.exports = {
  getAllStockMovements,
  getProductStockMovements,
  getStockMovementById
}
