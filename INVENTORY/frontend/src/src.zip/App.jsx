import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { AuthProvider } from "./context/AuthContext"
import LoginPage from "./components/auth/LoginPage"
import DashboardLayout from "./components/layout/DashboardLayout"
import DashboardPage from "./components/dashboard/DashboardPage"
import ProductsPage from "./components/products/ProductsPage"
import CategoriesPage from "./components/categories/CategoryPage"
import InventoryPage from "./components/inventory/InventoryPage"
import StockMovementsPage from "./components/stockMovements/StockMovementsPage"
import PrivateRoute from "./components/auth/PrivateRoute"

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          {/* Public routes */}
          <Route path="/login" element={<LoginPage />} />

          {/* Private routes */}
          <Route
            path="/"
            element={
              <PrivateRoute>
                <DashboardLayout />
              </PrivateRoute>
            }
          >
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="categories" element={<CategoriesPage />} />
            <Route path="inventory" element={<InventoryPage />} />
            <Route path="stock-movements" element={<StockMovementsPage />} />
          </Route>

          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </Router>
  )
}

export default App
