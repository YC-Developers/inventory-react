"use client"

import React, { useState } from "react"
import { Modal, Form, Input, Select, InputNumber, Button, message } from "antd"
import { stockMovementService } from "../../services/api"

const { Option } = Select

const StockMovementForm = ({ visible, onCancel, onSave, product }) => {
  const [form] = Form.useForm()
  const [loading, setLoading] = useState(false)

  React.useEffect(() => {
    if (visible && product) {
      form.setFieldsValue({
        productId: product._id,
        type: "in",
        quantity: 1,
        reason: "",
      })
    }
  }, [visible, product, form])

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields()
      setLoading(true)

      await stockMovementService.create({
        product: values.productId,
        type: values.type,
        quantity: values.quantity,
        reason: values.reason,
      })

      message.success(`Stock ${values.type === "in" ? "added" : "removed"} successfully`)
      form.resetFields()
      onSave()
    } catch (error) {
      if (error.errorFields) {
        return // Form validation error
      }
      message.error("Failed to save stock movement")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      title={`Add Stock Movement for ${product?.name || ""}`}
      visible={visible}
      onCancel={onCancel}
      footer={[
        <Button key="cancel" onClick={onCancel}>
          Cancel
        </Button>,
        <Button key="submit" type="primary" loading={loading} onClick={handleSubmit}>
          Save
        </Button>,
      ]}
    >
      <Form form={form} layout="vertical">
        <Form.Item name="productId" hidden>
          <Input />
        </Form.Item>

        <Form.Item
          name="type"
          label="Movement Type"
          rules={[{ required: true, message: "Please select movement type" }]}
        >
          <Select>
            <Option value="in">Stock In</Option>
            <Option value="out">Stock Out</Option>
          </Select>
        </Form.Item>

        <Form.Item
          name="quantity"
          label="Quantity"
          rules={[
            { required: true, message: "Please enter quantity" },
            { type: "number", min: 1, message: "Quantity must be at least 1" },
          ]}
        >
          <InputNumber min={1} style={{ width: "100%" }} />
        </Form.Item>

        <Form.Item name="reason" label="Reason" rules={[{ required: true, message: "Please enter a reason" }]}>
          <Input.TextArea rows={4} placeholder="Why is this stock being added or removed?" />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default StockMovementForm
