"use client"

import { useState, useEffect } from "react"
import { dashboardService } from "../../services/api"
import {
  ShoppingBagIcon,
  TagIcon,
  ExclamationTriangleIcon,
  ArrowsRightLeftIcon,
  ArrowUpIcon,
  ArrowDownIcon,
} from "@heroicons/react/24/outline"
import LowStockTable from "./LowStockTable"
import RecentMovementsTable from "./RecentMovementsTable"
import StockChart from "./StockChart"

const DashboardPage = () => {
  const [summary, setSummary] = useState({
    totalProducts: 0,
    totalCategories: 0,
    lowStockItems: 0,
    recentMovements: 0,
  })
  const [lowStockItems, setLowStockItems] = useState([])
  const [recentMovements, setRecentMovements] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      setError(null)

      const summaryData = await dashboardService.getSummary()
      setSummary(summaryData)

      const lowStockData = await dashboardService.getLowStock()
      setLowStockItems(lowStockData)

      const movementsData = await dashboardService.getRecentMovements()
      setRecentMovements(movementsData)
    } catch (err) {
      setError("Failed to load dashboard data. Please try again later.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-700"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-red-50 border-l-4 border-red-500 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <ExclamationTriangleIcon className="h-5 w-5 text-red-400" aria-hidden="true" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-secondary-900">Dashboard</h1>
        <p className="mt-1 text-sm text-secondary-500">Overview of your inventory system</p>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card bg-white overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 rounded-md p-3">
                <ShoppingBagIcon className="h-6 w-6 text-primary-600" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-secondary-500 truncate">Total Products</dt>
                  <dd>
                    <div className="text-lg font-medium text-secondary-900">{summary.totalProducts}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-secondary-50 px-5 py-3">
            <div className="text-sm">
              <a href="/products" className="font-medium text-primary-700 hover:text-primary-900">
                View all products
              </a>
            </div>
          </div>
        </div>

        <div className="card bg-white overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                <TagIcon className="h-6 w-6 text-blue-600" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-secondary-500 truncate">Total Categories</dt>
                  <dd>
                    <div className="text-lg font-medium text-secondary-900">{summary.totalCategories}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-secondary-50 px-5 py-3">
            <div className="text-sm">
              <a href="/categories" className="font-medium text-primary-700 hover:text-primary-900">
                View all categories
              </a>
            </div>
          </div>
        </div>

        <div className="card bg-white overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-yellow-100 rounded-md p-3">
                <ExclamationTriangleIcon className="h-6 w-6 text-yellow-600" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-secondary-500 truncate">Low Stock Items</dt>
                  <dd>
                    <div className="text-lg font-medium text-secondary-900">{summary.lowStockItems}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-secondary-50 px-5 py-3">
            <div className="text-sm">
              <a href="/inventory" className="font-medium text-primary-700 hover:text-primary-900">
                View inventory
              </a>
            </div>
          </div>
        </div>

        <div className="card bg-white overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-indigo-100 rounded-md p-3">
                <ArrowsRightLeftIcon className="h-6 w-6 text-indigo-600" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-secondary-500 truncate">Recent Movements</dt>
                  <dd>
                    <div className="text-lg font-medium text-secondary-900">{summary.recentMovements}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-secondary-50 px-5 py-3">
            <div className="text-sm">
              <a href="/stock-movements" className="font-medium text-primary-700 hover:text-primary-900">
                View all movements
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Charts and tables */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div className="card">
          <h2 className="text-lg font-medium text-secondary-900 mb-4">Stock Overview</h2>
          <StockChart />
        </div>

        <div className="card">
          <h2 className="text-lg font-medium text-secondary-900 mb-4">Stock Movement Trends</h2>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-green-100 rounded-md p-2">
                  <ArrowUpIcon className="h-5 w-5 text-green-600" aria-hidden="true" />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-green-800">Stock In</p>
                  <p className="text-2xl font-semibold text-green-900">
                    {recentMovements.filter((m) => m.type === "in").reduce((acc, curr) => acc + curr.quantity, 0)}
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <div className="relative h-2 bg-green-200 rounded-full overflow-hidden">
                  <div className="absolute h-full bg-green-500 rounded-full" style={{ width: "65%" }}></div>
                </div>
                <p className="mt-1 text-xs text-green-700">65% of total movements</p>
              </div>
            </div>

            <div className="bg-red-50 rounded-lg p-4">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-red-100 rounded-md p-2">
                  <ArrowDownIcon className="h-5 w-5 text-red-600" aria-hidden="true" />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-red-800">Stock Out</p>
                  <p className="text-2xl font-semibold text-red-900">
                    {recentMovements.filter((m) => m.type === "out").reduce((acc, curr) => acc + curr.quantity, 0)}
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <div className="relative h-2 bg-red-200 rounded-full overflow-hidden">
                  <div className="absolute h-full bg-red-500 rounded-full" style={{ width: "35%" }}></div>
                </div>
                <p className="mt-1 text-xs text-red-700">35% of total movements</p>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <h3 className="text-sm font-medium text-secondary-900 mb-3">Recent Stock Movements</h3>
            <RecentMovementsTable movements={recentMovements} />
          </div>
        </div>
      </div>

      {/* Low stock items */}
      <div className="card">
        <h2 className="text-lg font-medium text-secondary-900 mb-4">Low Stock Items</h2>
        <LowStockTable items={lowStockItems} />
      </div>
    </div>
  )
}

export default DashboardPage
