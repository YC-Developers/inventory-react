import { format } from "date-fns"
import { ArrowUpIcon, ArrowDownIcon } from "@heroicons/react/24/solid"

const RecentMovementsTable = ({ movements = [] }) => {
  if (movements.length === 0) {
    return (
      <div className="text-center py-6 bg-secondary-50 rounded-lg">
        <svg
          className="mx-auto h-12 w-12 text-secondary-400"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
          />
        </svg>
        <h3 className="mt-2 text-sm font-medium text-secondary-900">No recent movements</h3>
        <p className="mt-1 text-sm text-secondary-500">There have been no stock movements recently.</p>
      </div>
    )
  }

  return (
    <div className="overflow-hidden rounded-lg border border-secondary-200">
      <table className="min-w-full divide-y divide-secondary-200">
        <thead className="bg-secondary-50">
          <tr>
            <th
              scope="col"
              className="px-4 py-2 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider"
            >
              Product
            </th>
            <th
              scope="col"
              className="px-4 py-2 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider"
            >
              Type
            </th>
            <th
              scope="col"
              className="px-4 py-2 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider"
            >
              Qty
            </th>
            <th
              scope="col"
              className="px-4 py-2 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider"
            >
              Date
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-secondary-200">
          {movements.slice(0, 5).map((movement) => (
            <tr key={movement._id} className="hover:bg-secondary-50">
              <td className="px-4 py-2 whitespace-nowrap text-sm text-secondary-900">{movement.product.name}</td>
              <td className="px-4 py-2 whitespace-nowrap">
                {movement.type === "in" ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                    <ArrowUpIcon className="mr-1 h-3 w-3" aria-hidden="true" />
                    In
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
                    <ArrowDownIcon className="mr-1 h-3 w-3" aria-hidden="true" />
                    Out
                  </span>
                )}
              </td>
              <td className="px-4 py-2 whitespace-nowrap text-sm text-secondary-900">{movement.quantity}</td>
              <td className="px-4 py-2 whitespace-nowrap text-sm text-secondary-500">
                {format(new Date(movement.createdAt), "MMM d, yyyy")}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default RecentMovementsTable
