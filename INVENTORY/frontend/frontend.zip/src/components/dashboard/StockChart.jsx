"use client"

import { useEffect, useRef } from "react"
import Chart from "chart.js/auto"

const StockChart = () => {
  const chartRef = useRef(null)
  const chartInstance = useRef(null)

  useEffect(() => {
    // Sample data - in a real app, this would come from your API
    const data = {
      labels: ["Electronics", "Office Supplies", "Furniture", "Kitchen", "Clothing", "Books"],
      datasets: [
        {
          label: "Current Stock",
          data: [65, 42, 28, 35, 20, 15],
          backgroundColor: "rgba(22, 101, 52, 0.7)",
          borderColor: "rgba(22, 101, 52, 1)",
          borderWidth: 1,
        },
        {
          label: "Reorder Level",
          data: [25, 15, 10, 20, 10, 5],
          backgroundColor: "rgba(220, 38, 38, 0.5)",
          borderColor: "rgba(220, 38, 38, 1)",
          borderWidth: 1,
        },
      ],
    }

    if (chartRef.current) {
      // Destroy previous chart if it exists
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }

      // Create new chart
      const ctx = chartRef.current.getContext("2d")
      chartInstance.current = new Chart(ctx, {
        type: "bar",
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "top",
            },
            tooltip: {
              mode: "index",
              intersect: false,
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: "Quantity",
              },
            },
            x: {
              title: {
                display: true,
                text: "Category",
              },
            },
          },
        },
      })
    }

    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy()
      }
    }
  }, [])

  return (
    <div className="h-80">
      <canvas ref={chartRef}></canvas>
    </div>
  )
}

export default StockChart
