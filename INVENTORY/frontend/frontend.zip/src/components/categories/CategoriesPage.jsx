import React, { useState, useEffect } from 'react';
import { FaPlus, FaEdit, FaTrash } from 'react-icons/fa';
import api from '../../services/api';
import DashboardLayout from '../layout/DashboardLayout';
import CategoryForm from './CategoryForm';
import DeleteConfirmation from '../../common/DeleteConfirmation';

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [currentCategory, setCurrentCategory] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const response = await api.categories.getAll();
      setCategories(response.data);
      setLoading(false);
    } catch (err) {
      setError('Failed to load categories: ' + err.message);
      setLoading(false);
    }
  };

  const handleAddNew = () => {
    setCurrentCategory(null);
    setShowForm(true);
  };

  const handleEdit = (category) => {
    setCurrentCategory(category);
    setShowForm(true);
  };

  const handleDelete = (category) => {
    setCategoryToDelete(category);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    try {
      await api.categories.delete(categoryToDelete.categoryId);
      setCategories(categories.filter(c => c.categoryId !== categoryToDelete.categoryId));
      setShowDeleteModal(false);
      setCategoryToDelete(null);
    } catch (err) {
      setError('Failed to delete category: ' + err.message);
    }
  };

  const handleFormSubmit = async (formData) => {
    try {
      if (currentCategory) {
        // Update existing category
        const response = await api.categories.update(currentCategory.categoryId, formData);
        setCategories(categories.map(c => 
          c.categoryId === currentCategory.categoryId ? response.data : c
        ));
      } else {
        // Create new category
        const response = await api.categories.create(formData);
        setCategories([...categories, response.data]);
      }
      setShowForm(false);
    } catch (err) {
      setError('Failed to save category: ' + err.message);
    }
  };

  if (loading) {
    return (
      <DashboardLayout title="Categories">
        <div className="flex justify-center items-center h-full">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-darkred-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Categories">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold">Product Categories</h2>
          <button
            onClick={handleAddNew}
            className="bg-darkred-600 text-white px-4 py-2 rounded-md hover:bg-darkred-700 flex items-center"
          >
            <FaPlus className="mr-2" /> Add Category
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created At
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {categories.length === 0 ? (
                <tr>
                  <td colSpan="4" className="px-6 py-4 text-center text-gray-500">
                    No categories found. Add a new category to get started.
                  </td>
                </tr>
              ) : (
                categories.map((category) => (
                  <tr key={category.categoryId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{category.name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-500">{category.description}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {new Date(category.createdat).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleEdit(category)}
                        className="text-blue-600 hover:text-blue-900 mr-3"
                      >
                        <FaEdit />
                      </button>
                      <button
                        onClick={() => handleDelete(category)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <FaTrash />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <CategoryForm
          category={currentCategory}
          onSubmit={handleFormSubmit}
          onCancel={() => setShowForm(false)}
        />
      )}

      {showDeleteModal && (
        <DeleteConfirmation
          title="Delete Category"
          message={`Are you sure you want to delete the category "${categoryToDelete.name}"? This action cannot be undone.`}
          onConfirm={confirmDelete}
          onCancel={() => setShowDeleteModal(false)}
        />
      )}
    </DashboardLayout>
  );
};

export default CategoriesPage;
