"use client"

import { useState, useEffect } from "react"
import { productService, categoryService } from "../../services/api"
import {
  PlusIcon,
  PencilSquareIcon,
  TrashIcon,
  MagnifyingGlassIcon,
  ArrowDownIcon,
  ArrowUpIcon,
} from "@heroicons/react/24/outline"
import ProductForm from "./ProductForm"
import DeleteConfirmation from "../../common/DeleteConfirmation"

const ProductsPage = () => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(false)
  const [isFormModalVisible, setIsFormModalVisible] = useState(false)
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false)
  const [currentProduct, setCurrentProduct] = useState(null)
  const [searchText, setSearchText] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [sortField, setSortField] = useState("name")
  const [sortDirection, setSortDirection] = useState("asc")

  useEffect(() => {
    fetchProducts()
    fetchCategories()
  }, [])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const data = await productService.getAll()
      setProducts(data)
    } catch (error) {
      console.error("Failed to fetch products:", error)
      // Show error notification
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const data = await categoryService.getAll()
      setCategories(data)
    } catch (error) {
      console.error("Failed to fetch categories:", error)
    }
  }

  const handleAddProduct = () => {
    setCurrentProduct(null)
    setIsFormModalVisible(true)
  }

  const handleEditProduct = (product) => {
    setCurrentProduct(product)
    setIsFormModalVisible(true)
  }

  const handleDeleteClick = (product) => {
    setCurrentProduct(product)
    setIsDeleteModalVisible(true)
  }

  const handleDeleteConfirm = async () => {
    try {
      await productService.delete(currentProduct._id)
      setProducts(products.filter((p) => p._id !== currentProduct._id))
      setIsDeleteModalVisible(false)
      // Show success notification
    } catch (error) {
      console.error("Failed to delete product:", error)
      // Show error notification
    }
  }

  const handleFormSubmit = async (formData) => {
    try {
      if (currentProduct) {
        await productService.update(currentProduct._id, formData)
        setProducts(products.map((p) => (p._id === currentProduct._id ? { ...p, ...formData } : p)))
        // Show success notification
      } else {
        const newProduct = await productService.create(formData)
        setProducts([...products, newProduct])
        // Show success notification
      }
      setIsFormModalVisible(false)
    } catch (error) {
      console.error("Failed to save product:", error)
      // Show error notification
    }
  }

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  // Filter and sort products
  const filteredProducts = products
    .filter(
      (product) =>
        (searchText === "" ||
          product.name.toLowerCase().includes(searchText.toLowerCase()) ||
          product.sku.toLowerCase().includes(searchText.toLowerCase())) &&
        (selectedCategory === "" || product.category?._id === selectedCategory),
    )
    .sort((a, b) => {
      let comparison = 0

      if (sortField === "name") {
        comparison = a.name.localeCompare(b.name)
      } else if (sortField === "sku") {
        comparison = a.sku.localeCompare(b.sku)
      } else if (sortField === "price") {
        comparison = a.price - b.price
      } else if (sortField === "category") {
        comparison = (a.category?.name || "").localeCompare(b.category?.name || "")
      }

      return sortDirection === "asc" ? comparison : -comparison
    })

  const SortIcon = ({ field }) => {
    if (sortField !== field) return null
    return sortDirection === "asc" ? (
      <ArrowUpIcon className="h-4 w-4 ml-1" />
    ) : (
      <ArrowDownIcon className="h-4 w-4 ml-1" />
    )
  }

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-secondary-900">Products</h1>
          <p className="mt-1 text-sm text-secondary-500">Manage your product catalog</p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button type="button" onClick={handleAddProduct} className="btn btn-primary inline-flex items-center">
            <PlusIcon className="h-5 w-5 mr-2" aria-hidden="true" />
            Add Product
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow-sm rounded-lg p-4">
        <div className="sm:flex sm:items-center sm:justify-between">
          <div className="relative rounded-md shadow-sm max-w-xs">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-secondary-400" aria-hidden="true" />
            </div>
            <input
              type="text"
              className="input pl-10"
              placeholder="Search products"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>

          <div className="mt-4 sm:mt-0 sm:ml-4">
            <select className="input" value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
              <option value="">All Categories</option>
              {categories.map((category) => (
                <option key={category._id} value={category._id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="table-container">
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-700"></div>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12 bg-white">
            <svg
              className="mx-auto h-12 w-12 text-secondary-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
              />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-secondary-900">No products found</h3>
            <p className="mt-1 text-sm text-secondary-500">
              {searchText || selectedCategory
                ? "Try adjusting your search or filter to find what you're looking for."
                : "Get started by creating a new product."}
            </p>
            {!searchText && !selectedCategory && (
              <div className="mt-6">
                <button type="button" onClick={handleAddProduct} className="btn btn-primary inline-flex items-center">
                  <PlusIcon className="h-5 w-5 mr-2" aria-hidden="true" />
                  Add Product
                </button>
              </div>
            )}
          </div>
        ) : (
          <table className="table">
            <thead className="table-header">
              <tr>
                <th className="table-header-cell cursor-pointer" onClick={() => handleSort("sku")}>
                  <div className="flex items-center">
                    SKU
                    <SortIcon field="sku" />
                  </div>
                </th>
                <th className="table-header-cell cursor-pointer" onClick={() => handleSort("name")}>
                  <div className="flex items-center">
                    Name
                    <SortIcon field="name" />
                  </div>
                </th>
                <th className="table-header-cell cursor-pointer" onClick={() => handleSort("category")}>
                  <div className="flex items-center">
                    Category
                    <SortIcon field="category" />
                  </div>
                </th>
                <th className="table-header-cell cursor-pointer" onClick={() => handleSort("price")}>
                  <div className="flex items-center">
                    Price
                    <SortIcon field="price" />
                  </div>
                </th>
                <th className="table-header-cell">Actions</th>
              </tr>
            </thead>
            <tbody className="table-body">
              {filteredProducts.map((product) => (
                <tr key={product._id} className="table-row">
                  <td className="table-cell">{product.sku}</td>
                  <td className="table-cell font-medium">{product.name}</td>
                  <td className="table-cell">
                    {product.category ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                        {product.category.name}
                      </span>
                    ) : (
                      <span className="text-secondary-400">—</span>
                    )}
                  </td>
                  <td className="table-cell">${product.price.toFixed(2)}</td>
                  <td className="table-cell">
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleEditProduct(product)}
                        className="text-secondary-600 hover:text-secondary-900"
                      >
                        <PencilSquareIcon className="h-5 w-5" aria-hidden="true" />
                        <span className="sr-only">Edit</span>
                      </button>
                      <button onClick={() => handleDeleteClick(product)} className="text-red-600 hover:text-red-900">
                        <TrashIcon className="h-5 w-5" aria-hidden="true" />
                        <span className="sr-only">Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Product Form Modal */}
      {isFormModalVisible && (
        <ProductForm
          product={currentProduct}
          categories={categories}
          onSave={handleFormSubmit}
          onCancel={() => setIsFormModalVisible(false)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalVisible && (
        <DeleteConfirmation
          title="Delete Product"
          message={`Are you sure you want to delete "${currentProduct?.name}"? This action cannot be undone.`}
          onConfirm={handleDeleteConfirm}
          onCancel={() => setIsDeleteModalVisible(false)}
        />
      )}
    </div>
  )
}

export default ProductsPage
