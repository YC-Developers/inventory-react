"use client"

import { useState } from "react"
import { useAuth } from "../../context/AuthContext"
import {
  Bars3Icon,
  BellIcon,
  MagnifyingGlassIcon,
  UserIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
} from "@heroicons/react/24/outline"

const Topbar = ({ onMenuButtonClick }) => {
  const { user, logout } = useAuth()
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false)
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm z-10">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <button
              type="button"
              className="lg:hidden -ml-2 inline-flex items-center justify-center rounded-md p-2 text-secondary-500 hover:bg-secondary-100 hover:text-secondary-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
              onClick={onMenuButtonClick}
            >
              <span className="sr-only">Open sidebar</span>
              <Bars3Icon className="h-6 w-6" aria-hidden="true" />
            </button>

            <div className="hidden lg:block lg:ml-2">
              <div className="flex items-center">
                <div className="relative max-w-xs">
                  <label htmlFor="search" className="sr-only">
                    Search
                  </label>
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <MagnifyingGlassIcon className="h-5 w-5 text-secondary-400" aria-hidden="true" />
                  </div>
                  <input
                    id="search"
                    name="search"
                    className="block w-full rounded-md border border-secondary-300 bg-white py-2 pl-10 pr-3 text-sm placeholder-secondary-500 focus:border-primary-500 focus:text-secondary-900 focus:placeholder-secondary-400 focus:outline-none focus:ring-1 focus:ring-primary-500"
                    placeholder="Search"
                    type="search"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center">
            {/* Notifications dropdown */}
            <div className="relative ml-4">
              <button
                type="button"
                className="flex-shrink-0 rounded-full bg-white p-1 text-secondary-400 hover:text-secondary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              >
                <span className="sr-only">View notifications</span>
                <BellIcon className="h-6 w-6" aria-hidden="true" />
              </button>

              {/* Notification badge */}
              <div className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 flex items-center justify-center">
                <span className="text-xs text-white font-bold">3</span>
              </div>

              {/* Notifications dropdown menu */}
              {isNotificationsOpen && (
                <div className="absolute right-0 z-10 mt-2 w-80 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="px-4 py-2 border-b border-secondary-200">
                    <h3 className="text-sm font-medium text-secondary-900">Notifications</h3>
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    <a href="#" className="block px-4 py-2 hover:bg-secondary-50">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 bg-red-100 rounded-full p-1">
                          <svg
                            className="h-5 w-5 text-red-600"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </div>
                        <div className="ml-3 w-0 flex-1">
                          <p className="text-sm font-medium text-secondary-900">Low stock alert</p>
                          <p className="mt-1 text-sm text-secondary-500">
                            Product "Wireless Keyboard" is running low on stock.
                          </p>
                          <p className="mt-1 text-xs text-secondary-400">5 minutes ago</p>
                        </div>
                      </div>
                    </a>
                    <a href="#" className="block px-4 py-2 hover:bg-secondary-50">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 bg-green-100 rounded-full p-1">
                          <svg
                            className="h-5 w-5 text-green-600"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </div>
                        <div className="ml-3 w-0 flex-1">
                          <p className="text-sm font-medium text-secondary-900">Stock updated</p>
                          <p className="mt-1 text-sm text-secondary-500">
                            New stock of "Wireless Mouse" has been added.
                          </p>
                          <p className="mt-1 text-xs text-secondary-400">1 hour ago</p>
                        </div>
                      </div>
                    </a>
                    <a href="#" className="block px-4 py-2 hover:bg-secondary-50">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 bg-blue-100 rounded-full p-1">
                          <svg
                            className="h-5 w-5 text-blue-600"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                          </svg>
                        </div>
                        <div className="ml-3 w-0 flex-1">
                          <p className="text-sm font-medium text-secondary-900">New order</p>
                          <p className="mt-1 text-sm text-secondary-500">Order #12345 has been placed.</p>
                          <p className="mt-1 text-xs text-secondary-400">3 hours ago</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  <div className="border-t border-secondary-200 px-4 py-2">
                    <a href="#" className="text-sm font-medium text-primary-600 hover:text-primary-500">
                      View all notifications
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* Profile dropdown */}
            <div className="relative ml-4">
              <button
                type="button"
                className="flex max-w-xs items-center rounded-full bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              >
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-primary-700 flex items-center justify-center text-white font-medium">
                  {user?.name?.charAt(0) || "U"}
                </div>
              </button>

              {isProfileMenuOpen && (
                <div className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="px-4 py-2 border-b border-secondary-200">
                    <p className="text-sm font-medium text-secondary-900">{user?.name || "User"}</p>
                    <p className="text-xs text-secondary-500">{user?.email || "user@example.com"}</p>
                  </div>
                  <a
                    href="/profile"
                    className="flex items-center px-4 py-2 text-sm text-secondary-700 hover:bg-secondary-100"
                  >
                    <UserIcon className="mr-3 h-5 w-5 text-secondary-400" aria-hidden="true" />
                    Your Profile
                  </a>
                  <a
                    href="/settings"
                    className="flex items-center px-4 py-2 text-sm text-secondary-700 hover:bg-secondary-100"
                  >
                    <Cog6ToothIcon className="mr-3 h-5 w-5 text-secondary-400" aria-hidden="true" />
                    Settings
                  </a>
                  <button
                    onClick={logout}
                    className="flex w-full items-center px-4 py-2 text-sm text-secondary-700 hover:bg-secondary-100"
                  >
                    <ArrowRightOnRectangleIcon className="mr-3 h-5 w-5 text-secondary-400" aria-hidden="true" />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Topbar
