"use client"

import { Link, useLocation } from "react-router-dom"
import { useAuth } from "../../context/AuthContext"
import {
  HomeIcon,
  CubeIcon,
  TagIcon,
  ArchiveBoxIcon,
  ArrowsRightLeftIcon,
  UserIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
} from "@heroicons/react/24/outline"

const Sidebar = ({ mobile = false, closeSidebar = () => {} }) => {
  const location = useLocation()
  const { user, logout } = useAuth()

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: HomeIcon },
    { name: "Products", href: "/products", icon: CubeIcon },
    { name: "Categories", href: "/categories", icon: TagIcon },
    { name: "Inventory", href: "/inventory", icon: ArchiveBoxIcon },
    { name: "Stock Movements", href: "/stock-movements", icon: ArrowsRightLeftIcon },
  ]

  const userNavigation = [
    { name: "Your Profile", href: "/profile", icon: UserIcon },
    { name: "Settings", href: "/settings", icon: Cog6ToothIcon },
  ]

  const isActive = (path) => {
    return location.pathname === path
  }

  const handleClick = (mobile) => {
    if (mobile) {
      closeSidebar()
    }
  }

  return (
    <>
      <div className="flex flex-shrink-0 items-center px-4">
        <img className="h-8 w-auto" src="/logo.svg" alt="Inventory System" />
        <h1 className="ml-3 text-xl font-bold text-white">Inventory</h1>
      </div>

      <div className="mt-8 flex flex-1 flex-col">
        <nav className="flex-1 space-y-1 px-2">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`
                group flex items-center px-2 py-2 text-sm font-medium rounded-md
                ${
                  isActive(item.href)
                    ? "bg-primary-800 text-white"
                    : "text-primary-100 hover:bg-primary-800 hover:text-white"
                }
              `}
              onClick={() => handleClick(mobile)}
            >
              <item.icon
                className={`
                  mr-3 h-6 w-6 flex-shrink-0
                  ${isActive(item.href) ? "text-white" : "text-primary-300 group-hover:text-white"}
                `}
                aria-hidden="true"
              />
              {item.name}
            </Link>
          ))}
        </nav>
      </div>

      <div className="border-t border-primary-800 pt-4 pb-3">
        <div className="flex items-center px-4">
          <div className="flex-shrink-0">
            <div className="h-10 w-10 rounded-full bg-primary-700 flex items-center justify-center text-white font-medium">
              {user?.name?.charAt(0) || "U"}
            </div>
          </div>
          <div className="ml-3">
            <div className="text-base font-medium text-white">{user?.name || "User"}</div>
            <div className="text-sm font-medium text-primary-300">{user?.email || "user@example.com"}</div>
          </div>
        </div>

        <div className="mt-3 space-y-1 px-2">
          {userNavigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-primary-100 hover:bg-primary-800 hover:text-white"
              onClick={() => handleClick(mobile)}
            >
              <item.icon
                className="mr-3 h-6 w-6 flex-shrink-0 text-primary-300 group-hover:text-white"
                aria-hidden="true"
              />
              {item.name}
            </Link>
          ))}

          <button
            onClick={logout}
            className="w-full group flex items-center px-2 py-2 text-sm font-medium rounded-md text-primary-100 hover:bg-primary-800 hover:text-white"
          >
            <ArrowRightOnRectangleIcon
              className="mr-3 h-6 w-6 flex-shrink-0 text-primary-300 group-hover:text-white"
              aria-hidden="true"
            />
            Sign out
          </button>
        </div>
      </div>
    </>
  )
}

export default Sidebar
