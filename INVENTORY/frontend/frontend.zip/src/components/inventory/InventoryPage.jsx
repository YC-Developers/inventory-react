"use client"

import { useState, useEffect } from "react"
import { Table, Button, message, Input, Spin, Tag } from "antd"
import { SearchOutlined, PlusOutlined } from "@ant-design/icons"
import { Navigate } from "react-router-dom"
import { inventoryService, productService } from "../../services/api"
import StockMovementForm from "../stockMovements/StockMovementForm"
import { useAuth } from "../../context/AuthContext"

const InventoryPage = () => {
  const { isAuthenticated, loading: authLoading } = useAuth()
  const [inventory, setInventory] = useState([])
  // eslint-disable-next-line no-unused-vars
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(false)
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [currentProduct, setCurrentProduct] = useState(null)
  const [searchText, setSearchText] = useState("")

  if (authLoading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <Spin size="large" tip="Loading..." />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  useEffect(() => {
    fetchInventory()
    fetchProducts()
  }, [])

  const fetchInventory = async () => {
    try {
      setLoading(true)
      const data = await inventoryService.getAll()
      setInventory(data)
    } catch (error) {
      message.error("Failed to fetch inventory")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const fetchProducts = async () => {
    try {
      const data = await productService.getAll()
      setProducts(data)
    } catch (error) {
      message.error("Failed to fetch products")
      console.error(error)
    }
  }

  const handleAddStockMovement = (product) => {
    setCurrentProduct(product)
    setIsModalVisible(true)
  }

  const handleSaveStockMovement = async () => {
    setIsModalVisible(false)
    fetchInventory()
  }

  const handleSearch = (e) => {
    setSearchText(e.target.value)
  }

  const getStockStatus = (quantity, reorderLevel) => {
    if (quantity <= 0) {
      return <Tag color="red">Out of Stock</Tag>
    } else if (quantity <= reorderLevel) {
      return <Tag color="orange">Low Stock</Tag>
    } else {
      return <Tag color="green">In Stock</Tag>
    }
  }

  const filteredInventory = inventory.filter(
    (item) =>
      item.product?.name.toLowerCase().includes(searchText.toLowerCase()) ||
      item.product?.sku.toLowerCase().includes(searchText.toLowerCase()),
  )

  const columns = [
    {
      title: "SKU",
      dataIndex: ["product", "sku"],
      key: "sku",
      sorter: (a, b) => a.product.sku.localeCompare(b.product.sku),
    },
    {
      title: "Product",
      dataIndex: ["product", "name"],
      key: "name",
      sorter: (a, b) => a.product.name.localeCompare(b.product.name),
    },
    {
      title: "Quantity",
      dataIndex: "quantity",
      key: "quantity",
      sorter: (a, b) => a.quantity - b.quantity,
    },
    {
      title: "Reorder Level",
      dataIndex: "reorderLevel",
      key: "reorderLevel",
    },
    {
      title: "Status",
      key: "status",
      render: (_, record) => getStockStatus(record.quantity, record.reorderLevel),
    },
    {
      title: "Last Updated",
      dataIndex: "updatedAt",
      key: "updatedAt",
      render: (date) => new Date(date).toLocaleDateString(),
      sorter: (a, b) => new Date(a.updatedAt) - new Date(b.updatedAt),
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Button type="primary" icon={<PlusOutlined />} onClick={() => handleAddStockMovement(record.product)}>
          Add Stock Movement
        </Button>
      ),
    },
  ]

  return (
    <div className="inventory-page">
      <div className="page-header">
        <h1>Inventory</h1>
        <Input
          placeholder="Search products"
          prefix={<SearchOutlined />}
          onChange={handleSearch}
          value={searchText}
          style={{ width: 250 }}
        />
      </div>

      <Spin spinning={loading}>
        <Table columns={columns} dataSource={filteredInventory} rowKey="_id" pagination={{ pageSize: 10 }} />
      </Spin>

      <StockMovementForm
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        onSave={handleSaveStockMovement}
        product={currentProduct}
      />
    </div>
  )
}

export default InventoryPage
