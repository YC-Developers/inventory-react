"use client"

import { useState } from "react"
import { useAuth } from "../../context/AuthContext"
import { Alert, Button, Form, Input, Spin } from "antd"

const LoginForm = () => {
  const [form] = Form.useForm()
  const { login, loading, error } = useAuth()
  const [localError, setLocalError] = useState(null)

  const handleSubmit = async (values) => {
    try {
      setLocalError(null)
      await login(values.username, values.password)
    } catch (err) {
      setLocalError(err.response?.data?.message || "Login failed. Please check your credentials.")
    }
  }

  return (
    <div className="login-form-container">
      <h2>Login to Inventory System</h2>

      {(error || localError) && (
        <Alert message="Error" description={error || localError} type="error" showIcon style={{ marginBottom: 16 }} />
      )}

      <Spin spinning={loading}>
        <Form form={form} name="login" layout="vertical" onFinish={handleSubmit} autoComplete="off">
          <Form.Item
            label="Username"
            name="username"
            rules={[
              { required: true, message: "Please input your username!" },
              { type: "username", message: "Please enter a valid username !" },
            ]}
          >
            <Input placeholder="Enter your username" />
          </Form.Item>

          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <Input.Password placeholder="Enter your password" />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading} block>
              Log in
            </Button>
          </Form.Item>
        </Form>
      </Spin>
    </div>
  )
}

export default LoginForm
